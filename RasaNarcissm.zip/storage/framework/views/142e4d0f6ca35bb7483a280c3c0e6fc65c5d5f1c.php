<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="pricing-header p-3 pb-md-4 mx-auto mt-5 ">
        <h1 class="display-4 fw-normal text-body-emphasis fw-bold mb-5"><?php echo e($survey->title); ?></h1>
        <p class="fs-5 text-body-secondary mt-2">
            <?php echo $survey->description; ?>

        </p>
    </div>
    <?php if(!isset($currentQuestion) && !isset($firstQuestion)): ?>
        <button id="start-test" class="btn btn-lg btn-outline-dark mx-auto w-100">شروع</button>
    <?php endif; ?>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#start-test').on('click', function() {
        var isAuthenticated = <?php echo json_encode(Auth::check(), 15, 512) ?>;

        if (isAuthenticated) {
            window.location.href = "<?php echo e(route('surveys.public.question', $survey->slug)); ?>";
        } else {
            window.location.href = "<?php echo e(route('login', ['intended_url' => route('surveys.public.question', $survey->slug)])); ?>";
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP-Sallar\Documents\narcissism\Laravel\RasaNarcissm\resources\views/surveys/public_show.blade.php ENDPATH**/ ?>