<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Payment for <?php echo e($survey->title); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('payment.process', $survey->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <p>To access this survey, you need to pay <?php echo e($survey->price); ?>.</p>

                        <!-- Implement your payment form here -->

                        <button type="submit" class="btn btn-primary">Pay Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP-Sallar\Documents\narcissism\Laravel\RasaNarcissm\resources\views/payments/show.blade.php ENDPATH**/ ?>