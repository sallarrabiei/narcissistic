<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Question</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('surveys.questions.update', [$survey->slug, $question->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="text">Question Text</label>
                            <input type="text" name="text" class="form-control" value="<?php echo e($question->text); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="option_type">Option Type (Optional)</label>
                            <select name="option_type_id" class="form-control">
                                <option value="">Select Option Type</option>
                                <?php $__currentLoopData = $optionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($optionType->id); ?>" <?php echo e($question->option_type_id == $optionType->id ? 'selected' : ''); ?>>
                                        <?php echo e($optionType->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="group_id">Group</label>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="group_id" value="<?php echo e($group->id); ?>" id="group<?php echo e($group->id); ?>" <?php echo e(isset($question) && $question->group_id == $group->id ? 'checked' : ''); ?> required>
                                    <label class="form-check-label" for="group<?php echo e($group->id); ?>">
                                        <?php echo e($group->name); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="form-group">
                            <label for="options">Options (Optional)</label>
                            <div id="options-container">
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="option-item">
                                        <input type="text" name="options[<?php echo e($index); ?>][label]" value="<?php echo e($option->label); ?>" placeholder="Label" class="form-control mb-2">
                                        <input type="number" name="options[<?php echo e($index); ?>][value]" value="<?php echo e($option->value); ?>" placeholder="Value" class="form-control mb-2">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" id="add-option" class="btn btn-secondary mt-2">Add Option</button>
                        </div>

                        <button type="submit" class="btn btn-primary mt-3">Update Question</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('add-option').addEventListener('click', function() {
        const container = document.getElementById('options-container');
        const index = container.getElementsByClassName('option-item').length;
        const optionItem = document.createElement('div');
        optionItem.className = 'option-item';
        optionItem.innerHTML = `
            <input type="text" name="options[${index}][label]" placeholder="Label" class="form-control mb-2">
            <input type="number" name="options[${index}][value]" placeholder="Value" class="form-control mb-2">
        `;
        container.appendChild(optionItem);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP-Sallar\Documents\narcissism\Laravel\RasaNarcissm\resources\views/surveys/edit_question.blade.php ENDPATH**/ ?>