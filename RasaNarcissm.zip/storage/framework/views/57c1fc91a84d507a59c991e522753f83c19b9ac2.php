<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">نتایج <?php echo e($survey->title); ?></div>

                <div class="card-body">
                    
                    
                    <?php if($averageScores): ?>
                        <h3>جدول امتیاز شما:</h3>
                        <table class="table my-5">

                        <?php $__currentLoopData = $averageScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $averageScore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($group); ?></td>
                            <td><b> <?php echo e($averageScore); ?></b></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    <?php endif; ?>
                    <?php if($analysisText): ?>
                        <p><?php echo $analysisText; ?></p>
                    <?php endif; ?>
                    <p  class="fs-5 text-body-secondary">ممنون از اینکه وقت گذاشتید و در این نظرسنجی شرکت کردید. هدف از این نظرسنجی قضاوت هیچ شخصی نیست، بلکه تنها به منظور آشنایی بیشتر شما با ویژگی‌های شخصیتی‌تان طراحی و اجرا شده است. امیدواریم این پرسشنامه به شما در شناخت بهتر خود و توسعه فردی کمک کند.

                    </p>

                    

                    
                    

                    <button id="share-twitter" class="btn btn-primary mt-3">به دوستان خود در توییتر وبسایت ما را معرفی کنید.</button>

                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<script>
document.getElementById('share-twitter').addEventListener('click', function() {
    var url = encodeURIComponent(window.location.href);
    var text = encodeURIComponent("من در  '<?php echo e($survey->title); ?>'  شرکت @rasatarin  کردم. شما هم شرکت کنید: www.narcissistic.ir <?php echo e($score); ?>.");
    var twitterUrl = `https://twitter.com/intent/tweet?url=${url}&text=${text}`;
    window.open(twitterUrl, '_blank', 'width=500,height=300');
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP-Sallar\Documents\narcissism\Laravel\RasaNarcissm\resources\views/surveys/public_result.blade.php ENDPATH**/ ?>