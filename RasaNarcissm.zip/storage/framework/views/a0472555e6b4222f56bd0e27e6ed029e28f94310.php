<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center  mt-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($survey->title); ?></div>

                <div class="card-body">
                    <?php if(isset($currentQuestion)): ?>
                        <?php
                            $question = $currentQuestion;
                        ?>

                        <form method="<?php echo e($currentIndex < count($survey->questions) - 1 ? 'GET' : 'POST'); ?>" action="<?php echo e($currentIndex < count($survey->questions) - 1 ? route('surveys.public.question', $survey->slug) : route('surveys.submit', $survey->slug)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="index" value="<?php echo e($currentIndex + 1); ?>">

                            <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionId => $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="responses[<?php echo e($questionId); ?>]" value="<?php echo e($response); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <h5><?php echo e($question->text); ?></h5>
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="responses[<?php echo e($question->id); ?>]" id="option_<?php echo e($option->id); ?>" value="<?php echo e($option->value); ?>" <?php echo e(isset($responses[$question->id]) && $responses[$question->id] == $option->value ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="option_<?php echo e($option->id); ?>">
                                        <?php echo e($option->label); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="d-flex justify-content-between mt-4">
                                
                                <?php if($currentIndex < count($survey->questions) - 1): ?>
                                    <button type="submit" class="btn btn-primary" id="next-button" disabled>Next Question</button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-success" id="next-button" disabled>Submit</button>
                                <?php endif; ?>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    function updateNextButtonState() {
        if ($('input[name="responses[<?php echo e($question->id); ?>]"]:checked').length > 0) {
            $('#next-button').prop('disabled', false);
        } else {
            $('#next-button').prop('disabled', true);
        }
    }

    $('input[name="responses[<?php echo e($question->id); ?>]"]').on('change', function() {
        updateNextButtonState();
    });

    // Initialize the state of the next button when the page loads
    updateNextButtonState();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP-Sallar\Documents\narcissism\Laravel\RasaNarcissm\resources\views/surveys/public_questions.blade.php ENDPATH**/ ?>