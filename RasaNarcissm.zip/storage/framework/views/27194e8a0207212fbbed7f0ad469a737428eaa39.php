<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header"><?php echo e($survey->title); ?></div>

                <div class="card-body">
                    <p><?php echo e($survey->description); ?></p>

                    <a href="<?php echo e(route('surveys.edit', $survey->slug)); ?>" class="btn btn-primary mb-3">Edit Survey</a>
                    <form action="<?php echo e(route('surveys.destroy', $survey->slug)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger mb-3" onclick="return confirm('Are you sure you want to delete this survey?')">Delete Survey</button>
                    </form>
                    <a href="<?php echo e(route('surveys.questions.create', $survey->slug)); ?>" class="btn btn-primary mb-3">Add Question</a>
                    
                    <a href="<?php echo e(route('groups.index', $survey->slug)); ?>" class="btn btn-primary mb-3">Manage Groups</a>

                    <ul class="list-group">
                        <?php $__currentLoopData = $survey->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($question->text); ?>

                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <a href="<?php echo e(route('surveys.questions.edit', ['survey' => $survey->slug, 'question' => $question->id])); ?>">Edit Question</a>
                                    <form action="<?php echo e(route('questions.destroy', ['survey' => $survey->slug, 'question' => $question->id])); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this question?')">Delete</button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP-Sallar\Documents\narcissism\Laravel\RasaNarcissm\resources\views/surveys/show.blade.php ENDPATH**/ ?>